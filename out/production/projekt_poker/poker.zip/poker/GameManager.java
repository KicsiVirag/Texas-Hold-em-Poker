package poker;
import com.sun.java.accessibility.util.TopLevelWindowListener;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import static poker.Player_hand.Actions.*;
import static poker.Cards.*;

public class GameManager {
    //játékmenet
    //győztes meghatározása után adjuk össze a nyereményt az emberhez


    private List<Cards> deck;
    private List<Cards> communityCards;
    private Rules rules;

    private int bet;
    private int currentBetToCall;
    private int pot;
    private int stage = 0;

    private int MAX_Players=10;
    private int MIN_Player = 2;
    private List<Player_hand> players = new ArrayList<>();
    private List<Integer> playersBet = new ArrayList<>();
    private int currentPLayer = 0;

    private List<Boolean> floded = new ArrayList<>();
    private List<Boolean> acted =new ArrayList<>();
    private boolean roundClosed = false;
    private boolean handFinished = false;


    public GameManager(){
        deck = Cards.createFulldeck();
        players = new ArrayList<Player_hand>();
        communityCards = new ArrayList<>();
        bet = 0;
        currentBetToCall = 0;
        pot = 0;
        rules = new Rules();
        Cards.Shuffle(deck);
        stage = 1;
    }

    public void addPlayer(){
        if(players.size() > MAX_Players){
            throw new IllegalStateException("Max 10 játékos lehet egyszerre");
        }
        if(roundClosed || handFinished){
            throw new IllegalStateException("Most nem léphetsz be a játékba");
        }
        players.add(new Player_hand(Cards.TwoCard(deck), 100));
        playersBet.add(0);
        floded.add(false);
        acted.add(false);
    }

    public List<Cards> dealCards(){
        return Cards.TwoCard(deck);
    }

    public void dealFlop(){
        if(stage == 1){
            for (int i = 0; i <3;i++){
                communityCards.add(deck.remove(0));
            }
        }
        stage++;
    }

    public void dealTurn(){
        if(stage == 2) {
            communityCards.add(deck.remove(0));
        }
        stage++;
    }

    public void dealRiver(){
        if(stage == 3) {
            communityCards.add(deck.remove(0));
        }
        stage++;
    }

    public int getPot(){
        return pot;
    }

    public List<Cards> getCommunityCard(){
        return new ArrayList<>(communityCards);
    }

    public String getHandStrenght(int playerIndex){
        if(communityCards.size() != 5){
            throw new IllegalStateException("Nincs meg az 5 lap a közös pakliban!");
        }
        return rules.Strength(players.get(playerIndex).getTwocard(), communityCards);
    }

    public String playerMove(int playerIndex, Player_hand.Actions actions, int amount){
        if(players.size()<2){
            throw new IllegalStateException("Nincs elég játékos");
        }
        if(roundClosed || handFinished){
            throw new IllegalStateException("Játékos nem léphet");
        }
        if(playerIndex != currentPLayer){
            throw  new IllegalStateException("Nem ez a játékos következik");
        }
        Player_hand player = players.get(playerIndex);

        int toCall = currentBetToCall - playersBet.get(playerIndex);
        int toPay = 0;

        switch (actions) {
            case CALL:
                toPay = toCall;
                break;

            case RAISE://ha valami 20, majd másik 50 emel akkor a 20asnak csak 30at kell emelnie
                toPay = amount -playersBet.get(playerIndex);
                break;

            case ALL_IN://ha valakinek 100 valakinek 40 allin akkor nem lesz egyenló (side pot)
                toPay = toCall;
                break;
            default:
                return "Nem támogatott lépés";
        }

        int moneyBefore = player.getMoney();

        String result = player.Move(actions, bet, currentBetToCall);

        int paid = moneyBefore-player.getMoney();

        pot+=paid;
        playersBet.set(playerIndex, paid);

        if (actions == FOLD){
            floded.set(playerIndex, true);
            pot = 0;
            handFinished = true;
            roundClosed = true;
            return result;
        }

        acted.set(playerIndex,true);
        if(!roundClosed){
            currentPLayer = (playerIndex+1)%players.size();
        }

        return result;
    }

}
